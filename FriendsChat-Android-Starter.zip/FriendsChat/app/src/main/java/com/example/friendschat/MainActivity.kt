package com.example.friendschat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF075E54)
private val BrightGreen = Color(0xFF128C7E)
private val PaleGreen = Color(0xFFE7F5EF)
private val Ink = Color(0xFF172522)
private val Muted = Color(0xFF71817C)

data class ChatPerson(val name: String, val message: String, val time: String, val unread: Int = 0, val color: Color)
data class ChatMessage(val text: String, val mine: Boolean)

private val samplePeople = listOf(
    ChatPerson("Aarav", "Are we meeting today?", "12:42", 2, Color(0xFF8BC7A7)),
    ChatPerson("Priya", "Sent you the photos 📸", "11:18", 1, Color(0xFFF0B7A4)),
    ChatPerson("College Friends", "Rohan: See you all soon!", "10:06", 4, Color(0xFFB9B1E8)),
    ChatPerson("Rohan", "Thanks bro!", "Yesterday", 0, Color(0xFFE8CB78)),
    ChatPerson("Ananya", "That was so funny 😂", "Yesterday", 0, Color(0xFF94C9D7))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FriendsChatApp() }
    }
}

@Composable
fun FriendsChatApp() {
    var tab by remember { mutableStateOf("Chats") }
    var openChat by remember { mutableStateOf<ChatPerson?>(null) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = BrightGreen, background = Color(0xFFF7FAF8))) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFFF7FAF8)) {
            if (openChat != null) {
                ConversationScreen(person = openChat!!, onBack = { openChat = null })
            } else {
                Column(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxWidth().background(Green).padding(start = 20.dp, end = 16.dp, top = 18.dp, bottom = 10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Friends Chat", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                Text("Stay close, wherever you are", color = Color(0xFFD1E8E2), fontSize = 12.sp)
                            }
                            IconButton(onClick = { }) { Icon(Icons.Default.CameraAlt, "Camera", tint = Color.White) }
                            IconButton(onClick = { }) { Icon(Icons.Default.Search, "Search", tint = Color.White) }
                            IconButton(onClick = { }) { Icon(Icons.Default.MoreVert, "More options", tint = Color.White) }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            listOf("Chats", "Status", "Calls", "Groups").forEach { label ->
                                Column(
                                    Modifier.weight(1f).clickable { tab = label }.padding(vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(label, color = Color.White, fontWeight = if (tab == label) FontWeight.Bold else FontWeight.Normal)
                                    Spacer(Modifier.height(6.dp))
                                    Box(Modifier.width(34.dp).height(3.dp).background(if (tab == label) Color.White else Color.Transparent, RoundedCornerShape(4.dp)))
                                }
                            }
                        }
                    }
                    when (tab) {
                        "Chats" -> ChatsList(onSelect = { openChat = it })
                        "Status" -> StatusScreen()
                        "Calls" -> CallsScreen()
                        "Groups" -> GroupsScreen(onSelect = { openChat = it })
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatsList(onSelect: (ChatPerson) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
        item {
            Row(Modifier.fillMaxWidth().clickable { }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).background(PaleGreen, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Archive, null, tint = Green)
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Archived", fontWeight = FontWeight.SemiBold, color = Ink)
                    Text("Your archived chats", color = Muted, fontSize = 12.sp)
                }
            }
        }
        items(samplePeople) { person ->
            Row(
                Modifier.fillMaxWidth().clickable { onSelect(person) }.padding(horizontal = 16.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(person.name, person.color, 52)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(person.name, fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 16.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(person.message, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Spacer(Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.End) {
                    Text(person.time, color = if (person.unread > 0) BrightGreen else Muted, fontSize = 11.sp)
                    if (person.unread > 0) {
                        Spacer(Modifier.height(5.dp))
                        Box(Modifier.size(20.dp).background(BrightGreen, CircleShape), contentAlignment = Alignment.Center) {
                            Text(person.unread.toString(), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            HorizontalDivider(color = Color(0xFFE9EFEC), thickness = 0.6.dp, modifier = Modifier.padding(start = 80.dp))
        }
    }
}

@Composable
private fun Avatar(name: String, color: Color, size: Int = 48) {
    Box(Modifier.size(size.dp).background(color, CircleShape), contentAlignment = Alignment.Center) {
        Text(name.split(" ").take(2).mapNotNull { it.firstOrNull()?.toString() }.joinToString(""), color = Color(0xFF20332E), fontWeight = FontWeight.Bold, fontSize = (size / 3.1).sp)
    }
}

@Composable
private fun ConversationScreen(person: ChatPerson, onBack: () -> Unit) {
    val messages = remember(person.name) {
        mutableStateListOf(
            ChatMessage("Hey! How are you? 😊", false),
            ChatMessage("I'm good! What's up?", true),
            ChatMessage(person.message, false)
        )
    }
    var draft by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Color(0xFFEFF5F1))) {
        Row(Modifier.fillMaxWidth().background(Green).padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Avatar(person.name, person.color, 40)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(person.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                Text("demo conversation", color = Color(0xFFD1E8E2), fontSize = 11.sp)
            }
            IconButton(onClick = { }) { Icon(Icons.Default.Call, "Voice call", tint = Color.White) }
            IconButton(onClick = { }) { Icon(Icons.Default.Videocam, "Video call", tint = Color.White) }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text("Messages are demo-only in this starter.", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(8.dp))
            }
            items(messages) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.mine) Arrangement.End else Arrangement.Start) {
                    Column(
                        Modifier.widthIn(max = 300.dp).background(if (msg.mine) Color(0xFFD5F5DF) else Color.White, RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 9.dp)
                    ) {
                        Text(msg.text, color = Ink, fontSize = 15.sp)
                        Text(if (msg.mine) "now  ✓✓" else "12:40", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.End))
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Color(0xFFEFF5F1)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).background(Color.White, RoundedCornerShape(28.dp)).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.EmojiEmotions, null, tint = Muted)
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f)) {
                    if (draft.isEmpty()) Text("Message", color = Muted)
                    BasicTextField(value = draft, onValueChange = { draft = it }, singleLine = true, modifier = Modifier.fillMaxWidth(), textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 15.sp))
                }
                Icon(Icons.Default.AttachFile, null, tint = Muted)
            }
            Spacer(Modifier.width(7.dp))
            IconButton(onClick = {
                if (draft.isNotBlank()) {
                    messages.add(ChatMessage(draft.trim(), true))
                    draft = ""
                }
            }, modifier = Modifier.size(48.dp).background(BrightGreen, CircleShape)) {
                Icon(if (draft.isBlank()) Icons.Default.Mic else Icons.Default.Send, "Send message", tint = Color.White)
            }
        }
    }
}

@Composable
private fun StatusScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Status", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Share a moment with your friends", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box {
                Avatar("You", BrightGreen, 56)
                Box(Modifier.align(Alignment.BottomEnd).size(22.dp).background(Green, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(16.dp))
                }
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text("My status", fontWeight = FontWeight.SemiBold, color = Ink)
                Text("Tap to add a status update", color = Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(22.dp))
        Text("RECENT UPDATES", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        listOf("Priya", "Aarav", "Ananya").forEachIndexed { i, name ->
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.background(Color.Transparent, CircleShape).padding(3.dp).background(BrightGreen, CircleShape).padding(3.dp)) {
                    Avatar(name, listOf(Color(0xFFF0B7A4), Color(0xFF8BC7A7), Color(0xFF94C9D7))[i], 46)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(name, fontWeight = FontWeight.SemiBold, color = Ink)
                    Text(listOf("Today, 12:30 PM", "Today, 11:45 AM", "Today, 10:10 AM")[i], color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun CallsScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Calls", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Your recent calls will appear here", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        listOf("Aarav", "Priya", "College Friends").forEachIndexed { i, name ->
            Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(name, listOf(Color(0xFF8BC7A7), Color(0xFFF0B7A4), Color(0xFFB9B1E8))[i], 50)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, fontWeight = FontWeight.SemiBold, color = Ink)
                    Text(if (i == 1) "Incoming voice call · Yesterday" else "Outgoing video call · Yesterday", color = Muted, fontSize = 12.sp)
                }
                Icon(if (i == 1) Icons.Default.CallReceived else Icons.Default.CallMade, null, tint = BrightGreen)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Calling is a visual demo only. Real calls require WebRTC, signaling, and TURN infrastructure.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun GroupsScreen(onSelect: (ChatPerson) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Groups", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Chat with everyone in one place", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().clickable { onSelect(samplePeople[2]) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar("College Friends", Color(0xFFB9B1E8), 52)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("College Friends", fontWeight = FontWeight.SemiBold, color = Ink)
                Text("Rohan: See you all soon!", color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
        Row(Modifier.fillMaxWidth().clickable { onSelect(ChatPerson("Weekend Plan", "Where shall we go?", "09:15", 0, Color(0xFF8BC7A7))) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar("Weekend Plan", Color(0xFF8BC7A7), 52)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Weekend Plan", fontWeight = FontWeight.SemiBold, color = Ink)
                Text("Where shall we go?", color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
        Spacer(Modifier.height(12.dp))
        Text("Group creation and shared messages are demo-only for now.", color = Muted, fontSize = 12.sp)
    }
}
